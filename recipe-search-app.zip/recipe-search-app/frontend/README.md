# Frontend - recipe-search-app

React UI for Recipe Search App.

## Run

From the `frontend/` folder:

```bash
npm install
npm start
```

Make sure backend is running at `http://localhost:8080`.
