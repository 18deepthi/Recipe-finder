export async function fetchRecipes(ingredients) {
  const params = new URLSearchParams();
  if (ingredients) {
    params.append('ingredients', ingredients);
  }
  const response = await fetch(`http://localhost:8080/api/recipes?${params.toString()}`);
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
}
