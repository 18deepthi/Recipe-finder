import React, { useState } from 'react';
import SearchBar from './components/SearchBar';
import RecipeList from './components/RecipeList';
import { fetchRecipes } from './services/api';

const App = () => {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSearch = async (ingredients) => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchRecipes(ingredients);
      setRecipes(data);
    } catch (err) {
      setError('Failed to load recipes. Is backend running?');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <h1>Recipe Search App</h1>
      <p>Enter ingredients separated by commas (e.g., tomato,onion,rice)</p>
      <SearchBar onSearch={handleSearch} />
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      <RecipeList recipes={recipes} />
    </div>
  );
};

export default App;
