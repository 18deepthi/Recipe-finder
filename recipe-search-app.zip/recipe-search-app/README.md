# 🍽️ recipe-search-app

A medium-level full stack project where users can search recipes based on ingredients.

- Backend: Spring Boot, JDBC, MySQL
- Frontend: React, JavaScript, HTML, CSS
- Database name: `recipe`
- MySQL username: `recipe`

## Structure

- `backend/` – Spring Boot REST API
- `frontend/` – React UI

See each folder's README or instructions for how to run.
