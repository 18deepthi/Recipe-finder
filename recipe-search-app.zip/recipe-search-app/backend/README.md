# Backend - recipe-search-app

Spring Boot REST API for searching recipes by ingredients.

## Run

1. Create MySQL database named `recipe`
2. Create MySQL user `recipe` with password `recipe` and grant access to `recipe` database
3. Run the SQL in `src/main/resources/schema.sql` (or configure Spring to run it automatically)
4. From `backend/` folder run:

```bash
mvn clean install
mvn spring-boot:run
```

API:
- GET `http://localhost:8080/api/recipes?ingredients=tomato,onion`
