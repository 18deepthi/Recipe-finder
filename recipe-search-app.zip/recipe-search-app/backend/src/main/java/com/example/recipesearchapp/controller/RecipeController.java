package com.example.recipesearchapp.controller;

import com.example.recipesearchapp.model.Recipe;
import com.example.recipesearchapp.service.RecipeService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class RecipeController {

    private final RecipeService recipeService;

    public RecipeController(RecipeService recipeService) {
        this.recipeService = recipeService;
    }

    @GetMapping("/api/recipes")
    public List<Recipe> searchRecipes(@RequestParam(value = "ingredients", required = false) String ingredients) {
        return recipeService.searchByIngredients(ingredients);
    }
}
