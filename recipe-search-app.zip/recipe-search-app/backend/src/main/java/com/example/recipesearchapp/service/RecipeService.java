package com.example.recipesearchapp.service;

import com.example.recipesearchapp.model.Recipe;
import com.example.recipesearchapp.repository.RecipeRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RecipeService {

    private final RecipeRepository recipeRepository;

    public RecipeService(RecipeRepository recipeRepository) {
        this.recipeRepository = recipeRepository;
    }

    public List<Recipe> searchByIngredients(String ingredientsCsv) {
        if (ingredientsCsv == null || ingredientsCsv.isBlank()) {
            return recipeRepository.findAll();
        }

        List<String> ingredients = Arrays.stream(ingredientsCsv.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(String::toLowerCase)
                .collect(Collectors.toList());

        return recipeRepository.findByIngredientNames(ingredients);
    }
}
