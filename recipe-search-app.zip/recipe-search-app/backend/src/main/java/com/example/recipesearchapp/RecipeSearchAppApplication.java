package com.example.recipesearchapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeSearchAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(RecipeSearchAppApplication.class, args);
    }
}
