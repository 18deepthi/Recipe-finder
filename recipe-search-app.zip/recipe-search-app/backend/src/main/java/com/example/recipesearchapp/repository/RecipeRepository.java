package com.example.recipesearchapp.repository;

import com.example.recipesearchapp.model.Recipe;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RecipeRepository {

    private final JdbcTemplate jdbcTemplate;

    public RecipeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Recipe> recipeRowMapper = (rs, rowNum) ->
            new Recipe(
                    rs.getLong("id"),
                    rs.getString("name"),
                    rs.getString("description")
            );

    public List<Recipe> findByIngredientNames(List<String> ingredients) {
        if (ingredients == null || ingredients.isEmpty()) {
            return List.of();
        }

        String placeholders = String.join(",", ingredients.stream().map(i -> "?").toList());

        String sql = "SELECT DISTINCT r.id, r.name, r.description " +
                "FROM recipes r " +
                "JOIN recipe_ingredients ri ON r.id = ri.recipe_id " +
                "JOIN ingredients i ON ri.ingredient_id = i.id " +
                "WHERE i.name IN (" + placeholders + ")";

        return jdbcTemplate.query(sql, recipeRowMapper, ingredients.toArray());
    }

    public List<Recipe> findAll() {
        String sql = "SELECT id, name, description FROM recipes";
        return jdbcTemplate.query(sql, recipeRowMapper);
    }
}
