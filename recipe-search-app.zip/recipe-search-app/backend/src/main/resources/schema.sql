CREATE TABLE IF NOT EXISTS recipes (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS ingredients (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS recipe_ingredients (
    recipe_id BIGINT NOT NULL,
    ingredient_id BIGINT NOT NULL,
    PRIMARY KEY (recipe_id, ingredient_id),
    FOREIGN KEY (recipe_id) REFERENCES recipes(id),
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
);

INSERT INTO recipes (name, description) VALUES
('Tomato Pasta', 'Simple pasta with tomato sauce'),
('Veg Fried Rice', 'Fried rice with mixed vegetables'),
('Paneer Curry', 'Paneer cooked in rich gravy');

INSERT INTO ingredients (name) VALUES
('tomato'), ('onion'), ('rice'), ('paneer'), ('capsicum'), ('garlic')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO recipe_ingredients (recipe_id, ingredient_id)
SELECT r.id, i.id FROM recipes r, ingredients i
WHERE (r.name = 'Tomato Pasta' AND i.name IN ('tomato','garlic')) OR
      (r.name = 'Veg Fried Rice' AND i.name IN ('rice','capsicum','onion')) OR
      (r.name = 'Paneer Curry' AND i.name IN ('paneer','tomato','onion'));
